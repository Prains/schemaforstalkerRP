-- The 'nice' name of the faction.
FACTION.name = "Duty"
-- A description used in tooltips in various menus.
FACTION.desc = "Wastelander in a post-apocalypsis wasteland"
-- A color to distinguish factions from others, used for stuff such as
-- name color in OOC chat.
FACTION.color = Color(0, 0, 0)
FACTION.maleModels = {"models/player/scavenger/scavenger.mdl"
}
FACTION.femaleModels = {"models/stalkertnb/bandit_ewok.mdl"
}
FACTION.isDefault = false
FACTION.businessAllowed = false
-- FACTION.index is defined when the faction is registered and is just a numeric ID.
-- Here, we create a global variable for easier reference to the ID.
FACTION_CITIZEN = FACTION.index
