FACTION.name = "Stalker"
FACTION.desc = "Stalker"
FACTION.color = Color(0, 0, 255)
FACTION.Models = {"models/stalkertnb/bandit2.mdl"
}
FACTION.isDefault = true
FACTION.businessAllowed = false

FACTION_BROTHERHOOD = FACTION.index