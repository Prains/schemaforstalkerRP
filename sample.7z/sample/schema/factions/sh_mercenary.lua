FACTION.name = "Mercenary"
FACTION.desc = "Mercenary"
FACTION.color = Color(0, 0, 125)
FACTION.maleModels = {"models/f3v/seeker_09.mdl"
}
FACTION.isDefault = false

FACTION_BROTHERHOOD = FACTION.index