FACTION.name = "Military"
FACTION.desc = "Military"
FACTION.color = Color(0, 255, 255)
FACTION.isDefault = false
FACTION.maleModels = {"models/player/scavenger/scavenger.mdl"
}
FACTION.businessAllowed = false

FACTION_sinth = FACTION.index