FACTION.name = "Bandits"
FACTION.desc = "Raiders"
FACTION.color = Color(0, 0, 253)
FACTION.maleModels = {"models/half-dead/orderguy.mdl"
}
FACTION.isDefault = false
FACTION.businessAllowed = false
FACTION_RAIDERS = FACTION.index