ITEM.name = "Кровь Камня"
ITEM.desc = "Кровь Камня"
ITEM.category = "Артефакт"
ITEM.model = Model("models/predatorcz/stalker/artifacts/blood.mdl")
ITEM.price = 2000
ITEM.height = 1
ITEM.width = 1
ITEM.flag = "V"
