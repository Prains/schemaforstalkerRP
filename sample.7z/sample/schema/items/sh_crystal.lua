ITEM.name = "Крисстал"
ITEM.desc = "Крисстал"
ITEM.category = "Артефакт"
ITEM.model = Model("models/predatorcz/stalker/artifacts/crystal.mdl")
ITEM.price = 2500
ITEM.height = 1
ITEM.width = 1
ITEM.flag = "V"
