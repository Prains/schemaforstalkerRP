ITEM.name = "Small Bag"
ITEM.desc = "A small bag that does not carry much."
ITEM.invWidth = 2
ITEM.invHeight = 2
ITEM.permit = "misc"
ITEM.model = "models/props_c17/BriefCase001a.mdl"