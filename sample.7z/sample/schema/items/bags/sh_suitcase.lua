ITEM.name = "Suitcase"
ITEM.desc = "A small brown suitcase for extra storage."
ITEM.model = "models/props_c17/suitcase_passenger_physics.mdl"
ITEM.invWidth = 4
ITEM.invHeight = 3
ITEM.price = 50
ITEM.category = "Storage"
ITEM.permit = "misc"