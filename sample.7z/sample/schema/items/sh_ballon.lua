ITEM.name = "Пузырь"
ITEM.desc = "Пузырь"
ITEM.category = "Артефакт"
ITEM.model = Model("models/predatorcz/stalker/artifacts/ballon.mdl")
ITEM.price = 12000
ITEM.height = 1
ITEM.width = 1
ITEM.flag = "V"
