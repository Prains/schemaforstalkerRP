ITEM.name = "AKSU"
ITEM.desc = "AKSU"
ITEM.model = "models/weapons/w_ak74su.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_ak74su"
ITEM.height = 3
ITEM.width = 2
ITEM.price = 3500
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
ITEM.flag = "O"