ITEM.name = "M21ER"
ITEM.desc = "M21ER"
ITEM.model = "models/weapons/w_m14.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_m21emr"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 5560
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
ITEM.flag = "O"