ITEM.name = "Flamethrower"
ITEM.desc = "Flamethrower"
ITEM.model = "models/weapons/w_ai_flamethrower.mdl"
ITEM.category = "Оружие"
ITEM.class = "weapon_ai_flamethrower"
ITEM.height = 1
ITEM.width = 1
ITEM.price = 5560
ITEM.iconCam = {
    ang= Angle(-0.70499622821808, 268.25439453125, 0),
    fov= 12.085652091515,
    pos= Vector(0, 200, 0)
}
ITEM.flag = "O"