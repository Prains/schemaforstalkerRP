ITEM.name = "G36"
ITEM.desc = "G36"
ITEM.model = "models/weapons/w_g36c.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_g36k"
ITEM.price = 5650
ITEM.height = 1
ITEM.width = 2
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
ITEM.flag = "O"