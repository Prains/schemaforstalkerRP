ITEM.name = "Bulldog 6"
ITEM.desc = "Bulldog 6"
ITEM.model = Model("models/weapons/w_stalker_rg6.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_bulldog"
ITEM.class = "stalker_bulldog"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 15000
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"