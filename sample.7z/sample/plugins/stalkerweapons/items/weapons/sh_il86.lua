ITEM.name = "IL86"
ITEM.desc = "IL86"
ITEM.model = Model("models/weapons/w_stalker_enfield.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_enfield"
ITEM.class = "stalker_enfield"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 4560
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"