ITEM.name = "AS VAL"
ITEM.desc = "AS VAL"
ITEM.model = Model("models/weapons/v_rif_as_val.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_val"
ITEM.class = "stalker_val"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 5600
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"