ITEM.name = "Revolver"
ITEM.desc = "Revolver"
ITEM.model = Model("models/weapons/w_stalker_m9.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "srp_taurus"
ITEM.class = "srp_taurus"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 4500
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"