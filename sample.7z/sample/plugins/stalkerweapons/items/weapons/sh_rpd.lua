ITEM.name = "RPD"
ITEM.desc = "RPD"
ITEM.model = "models/weapons/w_pkm.mdl"
ITEM.category = "Оружие"
ITEM.class = "srp_pkm"
ITEM.height = 3
ITEM.width = 2
ITEM.price = 10000
ITEM.iconCam = {
ang= Angle(-0.70499622821808, 268.25439453125, 0),
fov= 12.085652091515,
pos= Vector(0, 200, 0)
}
ITEM.flag = "O"