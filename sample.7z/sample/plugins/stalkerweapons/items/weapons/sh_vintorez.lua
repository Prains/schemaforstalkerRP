ITEM.name = "Винторез"
ITEM.desc = "Винторез"
ITEM.model = Model("models/weapons/w_stalker_svd.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_vintorez"
ITEM.class = "stalker_vintorez"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 5600
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"