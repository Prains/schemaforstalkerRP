ITEM.name = "Eleminator"
ITEM.desc = "Eleminator"
ITEM.model = Model("models/weapons/w_stalker_striker.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_eliminator"
ITEM.class = "stalker_eliminator"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 3000
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"