ITEM.name = "Gauss Gun"
ITEM.desc = "Gauss Gun"
ITEM.model = Model("models/weapons/w_stalker_gauss.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_gauss"
ITEM.class = "stalker_gauss"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 1000000000
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"