ITEM.name = "FT200M"
ITEM.desc = "FT200M"
ITEM.model = Model("models/weapons/w_stalker_f2000.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_f2000"
ITEM.class = "stalker_f2000"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 5600
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"