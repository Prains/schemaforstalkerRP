ITEM.name = "Desert Eagle"
ITEM.desc = "Desert Eagle"
ITEM.model = Model("models/weapons/w_stalker_deagle.mdl")
ITEM.category = "Оружие"
ITEM.uniqueID = "stalker_deagle"
ITEM.class = "stalker_deagle"
ITEM.height = 1
ITEM.width = 1
ITEM.type = "rifle"
ITEM.price = 2500
ITEM.data = {
Equipped = false,
}
ITEM.flag = "O"