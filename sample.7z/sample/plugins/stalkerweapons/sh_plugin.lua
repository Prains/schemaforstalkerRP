PLUGIN.name = "Stalker weapons"
PLUGIN.author = "Prai'ns/DrodA"
PLUGIN.desc = "Weapons for StalkerRP"