ITEM.name = "Имя"
ITEM.desc = "Описание."
ITEM.category = "Одежда"
ITEM.model = "model"
