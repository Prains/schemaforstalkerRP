ITEM.name = "SEVA"
ITEM.desc = "SEVA"
ITEM.model = Model("models/stalkertnb/seva_black.mdl ")
ITEM.category = "Броня"
ITEM.price = 4500
ITEM.flag = "O"
